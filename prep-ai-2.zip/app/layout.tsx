import "./globals.css";
import type { Metadata } from "next";
export const metadata:Metadata={title:"Prep AI 2.0 | AI Career Preparation",description:"AI-powered interview and career preparation platform."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
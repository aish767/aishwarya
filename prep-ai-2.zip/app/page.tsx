 "use client";
import {useState} from "react";
import {BrainCircuit, Mic2, FileText, BarChart3, Users, Sparkles, ArrowRight, CheckCircle2} from "lucide-react";
import FeatureCard from "../components/FeatureCard";

export default function Home(){
 const [started,setStarted]=useState(false);
 const [role,setRole]=useState("Software Developer");
 const [level,setLevel]=useState("Intermediate");
 return <main>
  <nav className="nav"><div className="container" style={{display:"flex",width:"100%",justifyContent:"space-between",alignItems:"center"}}>
   <div className="logo">Prep<span>AI</span> 2.0</div>
   <div className="navlinks"><a href="#features">Features</a><a href="#dashboard">Dashboard</a><a href="#practice">Practice</a><button className="btn ghost" onClick={()=>setStarted(true)}>Sign in</button></div>
  </div></nav>

  <section className="hero"><div className="container heroGrid"><div>
   <span className="badge"><Sparkles size={13} style={{marginRight:5}}/> AI-powered career preparation</span>
   <h1>Prepare smarter.<br/><span>Perform better.</span></h1>
   <p>Practice interviews, improve your aptitude, analyse your resume and get personalized AI feedback — all in one place.</p>
   <div className="actions"><button className="btn primary" onClick={()=>setStarted(true)}>Start practicing <ArrowRight size={16} style={{verticalAlign:"middle",marginLeft:5}}/></button><a className="btn ghost" href="#features">Explore features</a></div>
  </div><div className="mock"><div className="mockTop"><i className="dot"/><i className="dot"/><i className="dot"/></div><div className="screen"><small style={{color:"#6b7280"}}>Today's preparation</small><h3>You're making progress 🚀</h3><div className="metric"><div><b>82%</b><small>Readiness</small></div><div><b>24</b><small>Questions</small></div><div><b>7</b><small>Day streak</small></div></div><div style={{marginTop:18}}><small>Interview readiness</small><div className="bar"><i style={{width:"82%"}}/></div></div></div></div>
  </div></section>

  <section className="section" id="features"><div className="container"><h2>Everything you need to get job-ready</h2><p className="sectionLead">A focused preparation workspace designed for students and job seekers.</p>
   <div className="cards">
    <FeatureCard icon={Mic2} title="AI Mock Interviews" text="Simulate HR and technical interviews with instant AI feedback on your answers."/>
    <FeatureCard icon={BrainCircuit} title="Aptitude Practice" text="Practice quantitative, logical and verbal questions with adaptive difficulty."/>
    <FeatureCard icon={FileText} title="Resume ATS Analyzer" text="Upload your resume and discover skills, keywords and improvements for your target role."/>
    <FeatureCard icon={Users} title="GD Simulator" text="Build confidence for group discussions with AI-generated topics and feedback."/>
    <FeatureCard icon={BarChart3} title="Performance Analytics" text="Track accuracy, consistency, strengths and weak areas from one dashboard."/>
    <FeatureCard icon={Sparkles} title="Personalized Prep" text="Get a preparation path based on your role, experience and current performance."/>
   </div>
  </div></section>

  <section className="section" id="dashboard"><div className="container"><div className="dashboard"><h2 style={{textAlign:"left",marginBottom:20}}>Your preparation dashboard</h2><div className="dashGrid"><div className="dashStat"><small>Overall score</small><b>82%</b></div><div className="dashStat"><small>Interview score</small><b>76%</b></div><div className="dashStat"><small>Aptitude accuracy</small><b>88%</b></div><div className="dashStat"><small>Questions solved</small><b>246</b></div></div><div style={{marginTop:22,display:"flex",gap:10,alignItems:"center"}}><CheckCircle2 size={19}/><span>Keep practicing 20 minutes a day to maintain your streak.</span></div></div></div></section>

  <section className="section" id="practice"><div className="container"><h2>Start a practice session</h2><p className="sectionLead">Choose your target role and difficulty. This demo runs entirely in your browser.</p>
   <div className="card" style={{maxWidth:650,margin:"auto"}}><label>Target role</label><select value={role} onChange={e=>setRole(e.target.value)} style={{width:"100%",padding:12,borderRadius:10,border:"1px solid #ddd",margin:"7px 0 16px"}}><option>Software Developer</option><option>Data Analyst</option><option>Business Analyst</option><option>Java Developer</option><option>Web Developer</option></select><label>Difficulty</label><select value={level} onChange={e=>setLevel(e.target.value)} style={{width:"100%",padding:12,borderRadius:10,border:"1px solid #ddd",margin:"7px 0 18px"}}><option>Beginner</option><option>Intermediate</option><option>Advanced</option></select><button className="btn primary" onClick={()=>setStarted(true)}>Generate practice questions</button></div>
  </div></section>

  <section className="section"><div className="container"><div className="cta"><h2>Ready to start preparing?</h2><p>Turn your preparation into a measurable daily habit.</p><button className="btn" onClick={()=>setStarted(true)}>Start PrepAI 2.0</button></div></div></section>
  <footer><div className="container footerIn"><span>© 2026 PrepAI 2.0 — Original project</span><span>Built with Next.js</span></div></footer>
  {started&&<div style={{position:"fixed",inset:0,background:"#111827aa",display:"grid",placeItems:"center",zIndex:50}}><div className="card" style={{maxWidth:480,margin:20}}><h2>Practice session</h2><p style={{color:"#6b7280"}}>Target: <b>{role}</b> · Level: <b>{level}</b></p><p>Sample question: <b>Tell me about yourself and explain why you are a good fit for this role.</b></p><textarea placeholder="Type your answer here..." style={{width:"100%",minHeight:120,padding:12,border:"1px solid #ddd",borderRadius:10}}/><div style={{display:"flex",gap:10,marginTop:14}}><button className="btn primary" onClick={()=>alert("AI feedback demo: Strong structure. Add measurable project results and keep your answer under 90 seconds.")}>Get AI feedback</button><button className="btn ghost" onClick={()=>setStarted(false)}>Close</button></div></div></div>}
 </main>
}
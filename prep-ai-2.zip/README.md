# Prep AI 2.0 — original starter

An original Next.js implementation inspired by the general concept of an AI career-preparation platform. It does not copy proprietary source code from another website.

## Run locally

1. Install Node.js 20.9+.
2. In this folder run:
   npm install
   npm run dev
3. Open http://localhost:3000

## Deploy

Push this folder to GitHub, then import the repository into Vercel. Vercel automatically detects Next.js projects. See the official Vercel deployment guidance: https://vercel.com/academy/ai-summary-app-with-nextjs/deploy-the-app

## Next upgrades

- Connect Clerk/Supabase for authentication and user data.
- Add an AI API route for real question generation and feedback.
- Add PostgreSQL/Supabase persistence.
- Add resume upload/ATS analysis.
- Add interview audio/video processing.
